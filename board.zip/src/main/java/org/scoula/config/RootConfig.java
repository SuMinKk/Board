// 패키지 선언: 이 클래스가 속한 패키지를 지정한다.
package org.scoula.config;

// HikariCP와 Spring 관련 클래스를 임포트한다.
import com.zaxxer.hikari.HikariConfig; // HikariCP의 설정 클래스
import com.zaxxer.hikari.HikariDataSource; // HikariCP의 데이터 소스 클래스
import org.apache.ibatis.session.SqlSessionFactory; // MyBatis의 SqlSessionFactory 인터페이스
import org.mybatis.spring.SqlSessionFactoryBean; // MyBatis의 SqlSessionFactoryBean 클래스
import org.mybatis.spring.annotation.MapperScan; // MyBatis 매퍼 인터페이스를 스캔하는 어노테이션
import org.springframework.beans.factory.annotation.Autowired; // Spring의 의존성 주입을 위한 어노테이션
import org.springframework.context.ApplicationContext; // Spring의 ApplicationContext 클래스
import org.springframework.context.annotation.Bean; // Spring의 Bean 정의 어노테이션
import org.springframework.context.annotation.ComponentScan; // Spring의 컴포넌트 스캔 어노테이션
import org.springframework.context.annotation.Configuration; // Spring의 설정 클래스를 정의하는 어노테이션
import org.springframework.context.annotation.PropertySource; // Spring의 프로퍼티 소스 설정 어노테이션

import javax.sql.DataSource; // JDBC의 DataSource 인터페이스
import org.springframework.beans.factory.annotation.Value; // Spring의 프로퍼티 값을 주입받기 위한 어노테이션
import org.springframework.jdbc.datasource.DataSourceTransactionManager; // Spring의 데이터 소스 트랜잭션 매니저

// 이 클래스는 Spring의 설정 클래스로, Bean을 정의하고 애플리케이션의 구성을 설정한다.
@Configuration

// 지정된 패키지에서 컴포넌트(서비스, 리포지토리 등)를 검색하고 Spring 컨테이너에 등록한다.
@ComponentScan(basePackages = { "org.scoula.board.service" })

// 지정된 패키지에서 MyBatis의 매퍼 인터페이스를 스캔하여 Spring 컨테이너에 등록한다.
@MapperScan(basePackages = { "org.scoula.board.mapper" })

// `application.properties` 파일에서 설정 값을 로드한다.
@PropertySource("classpath:/application.properties")

public class RootConfig {

    // application.properties 파일에서 'jdbc.driver' 값을 주입받아 사용한다.
    @Value("${jdbc.driver}") String driver;

    // application.properties 파일에서 'jdbc.url' 값을 주입받아 사용한다.
    @Value("${jdbc.url}") String url;

    // application.properties 파일에서 'jdbc.username' 값을 주입받아 사용한다.
    @Value("${jdbc.username}") String username;

    // application.properties 파일에서 'jdbc.password' 값을 주입받아 사용한다.
    @Value("${jdbc.password}") String password;

    // Spring 컨테이너가 DataSource 빈을 생성하고 관리하게 한다.
    @Bean
    public DataSource dataSource() {
        // HikariCP의 설정 객체를 생성한다.
        HikariConfig config = new HikariConfig();

        // 'jdbc.driver' 속성값을 HikariCP의 드라이버 클래스 이름으로 설정한다.
        config.setDriverClassName(driver);

        // 'jdbc.url' 속성값을 HikariCP의 JDBC URL로 설정한다.
        config.setJdbcUrl(url);

        // 'jdbc.username' 속성값을 HikariCP의 데이터베이스 사용자 이름으로 설정한다.
        config.setUsername(username);

        // 'jdbc.password' 속성값을 HikariCP의 데이터베이스 비밀번호로 설정한다.
        config.setPassword(password);

        // 설정을 기반으로 HikariDataSource 객체를 생성한다.
        HikariDataSource dataSource = new HikariDataSource(config);

        // 생성된 HikariDataSource 객체를 반환하여 Spring 컨테이너에 DataSource 빈으로 등록한다.
        return dataSource;
    }

    // ApplicationContext를 주입받아 사용한다.
    @Autowired
    ApplicationContext applicationContext;

    // MyBatis의 SqlSessionFactory 빈을 정의한다.
    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        // SqlSessionFactoryBean 객체를 생성한다.
        SqlSessionFactoryBean sqlSessionFactory = new SqlSessionFactoryBean();

        // 'mybatis-config.xml' 파일의 위치를 설정한다.
        sqlSessionFactory.setConfigLocation(
                applicationContext.getResource("classpath:/mybatis-config.xml"));

        // 설정된 DataSource를 SqlSessionFactoryBean에 설정한다.
        sqlSessionFactory.setDataSource(dataSource());

        // SqlSessionFactory 객체를 생성하여 반환한다.
        return (SqlSessionFactory) sqlSessionFactory.getObject();
    }

    // DataSourceTransactionManager 빈을 정의한다.
    @Bean
    public DataSourceTransactionManager transactionManager() {
        // DataSourceTransactionManager를 생성하고 DataSource를 설정한다.
        DataSourceTransactionManager manager = new DataSourceTransactionManager(dataSource());

        // 생성된 DataSourceTransactionManager 객체를 반환하여 Spring 컨테이너에 등록한다.
        return manager;
    }
}
