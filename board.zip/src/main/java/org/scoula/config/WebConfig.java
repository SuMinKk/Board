package org.scoula.config;

import lombok.extern.slf4j.Slf4j; // SLF4J 로그 출력을 위한 Lombok 어노테이션
import org.springframework.context.annotation.Configuration; // Spring의 설정 클래스를 정의하는 어노테이션
import org.springframework.web.filter.CharacterEncodingFilter; // 문자 인코딩 필터 클래스
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer; // DispatcherServlet 초기화 지원 클래스
import javax.servlet.Filter; // 서블릿 필터 인터페이스
import javax.servlet.MultipartConfigElement; // 파일 업로드 구성 요소 클래스
import javax.servlet.ServletRegistration; // 서블릿 등록 클래스

// 이 클래스는 Spring 웹 애플리케이션의 초기화 및 설정을 담당한다.
// @Slf4j 어노테이션을 사용하여 로그 출력을 지원한다.
@Slf4j
@Configuration
public class WebConfig extends AbstractAnnotationConfigDispatcherServletInitializer {

    // 파일 업로드와 관련된 설정 값
    final String LOCATION = "c:/upload"; // 업로드된 파일이 저장될 디렉토리 경로
    final long MAX_FILE_SIZE = 1024 * 1024 * 10L; // 업로드 가능한 파일 하나의 최대 크기 (10MB)
    final long MAX_REQUEST_SIZE = 1024 * 1024 * 20L; // 업로드 가능한 전체 최대 크기 (20MB)
    final int FILE_SIZE_THRESHOLD = 1024 * 1024 * 5; // 메모리 파일의 최대 크기 (5MB)

    @Override
    // 루트 애플리케이션 컨텍스트를 설정한다.
    // 이 메서드는 애플리케이션의 공통 설정 및 데이터베이스 연결 등 루트 컨텍스트를 정의한다.
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{RootConfig.class}; // RootConfig 클래스를 반환하여 루트 컨텍스트를 설정한다.
    }

    @Override
    // 서블릿 애플리케이션 컨텍스트를 설정한다.
    // 이 메서드는 MVC 관련 설정 및 컨트롤러 등록 등을 정의한다.
    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{ServletConfig.class}; // ServletConfig 클래스를 반환하여 서블릿 컨텍스트를 설정한다.
    }

    @Override
    // Spring의 DispatcherServlet이 처리할 URL 매핑 패턴을 설정한다.
    // 이 메서드는 모든 요청을 처리할 수 있도록 매핑을 정의한다.
    protected String[] getServletMappings() {
        return new String[]{"/"}; // 모든 URL 요청을 DispatcherServlet에 매핑한다.
    }

    @Override
    // POST 요청의 문자 인코딩을 설정하는 필터를 정의한다.
    // UTF-8 인코딩을 사용하도록 설정한다.
    protected Filter[] getServletFilters() {
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8"); // 문자 인코딩을 UTF-8로 설정한다.
        characterEncodingFilter.setForceEncoding(true); // 모든 요청에 대해 인코딩을 강제한다.

        return new Filter[]{characterEncodingFilter}; // 설정된 필터를 반환한다.
    }

    @Override
    // 서블릿 등록 시 커스터마이즈 설정을 정의한다.
    // 파일 업로드와 관련된 설정을 정의한다.
    protected void customizeRegistration(ServletRegistration.Dynamic registration) {
        // 예외 처리 설정: 핸들러가 없을 경우 예외를 던지도록 설정한다.
        registration.setInitParameter("throwExceptionIfNoHandlerFound", "true");

        // 파일 업로드 관련 설정을 정의한다.
        MultipartConfigElement multipartConfig = new MultipartConfigElement(
                LOCATION, // 업로드 처리 디렉토리 경로
                MAX_FILE_SIZE, // 업로드 가능한 파일 하나의 최대 크기
                MAX_REQUEST_SIZE, // 업로드 가능한 전체 최대 크기
                FILE_SIZE_THRESHOLD // 메모리 파일의 최대 크기
        );
        registration.setMultipartConfig(multipartConfig); // 설정을 등록한다.
    }
}
