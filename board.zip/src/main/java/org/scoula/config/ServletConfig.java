package org.scoula.config;

import org.springframework.context.annotation.Bean; // Spring의 Bean 정의 어노테이션
import org.springframework.context.annotation.ComponentScan; // Spring의 컴포넌트 스캔 어노테이션
import org.springframework.web.multipart.MultipartResolver; // Spring의 파일 업로드 처리 인터페이스
import org.springframework.web.multipart.support.StandardServletMultipartResolver; // Servlet 3.0 파일 업로드 처리 구현체
import org.springframework.web.servlet.config.annotation.EnableWebMvc; // Spring MVC를 활성화하는 어노테이션
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry; // 정적 자원 핸들러 설정 클래스
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry; // ViewResolver 설정 클래스
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer; // WebMvcConfigurer 인터페이스
import org.springframework.web.servlet.view.InternalResourceViewResolver; // JSP를 위한 ViewResolver 클래스
import org.springframework.web.servlet.view.JstlView; // JSP를 사용하는 뷰 클래스

// Spring MVC의 설정을 활성화한다.
// 이 어노테이션은 Spring MVC 관련 기능을 설정할 수 있도록 한다.
@EnableWebMvc

// 지정된 패키지에서 컴포넌트(컨트롤러, 예외 처리 등)를 검색하고 Spring 컨테이너에 등록한다.
// 이 경우, 컨트롤러가 위치할 패키지를 명시적으로 지정한다.
@ComponentScan(basePackages = {
        "org.scoula.controller",
        "org.scoula.exception",
        "org.scoula.ex03.controller",
        "org.scoula.board.controller"
})

public class ServletConfig implements WebMvcConfigurer {

    @Override
    //컨트롤러만 찾는다. 반드시 이 패키지에 컨트로러 적어줘야한다.
    // 정적 자원 핸들러를 추가한다.
    // 이 메서드는 정적 자원의 URL 경로와 실제 위치를 매핑하여 제공하는 역할을 한다.
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
                .addResourceHandler("/resources/**") // URL 패턴이 /resources/로 시작하는 모든 요청을 처리한다.
                .addResourceLocations("/resources/"); // 실제 자원 위치를 webapp/resources/로 설정한다.
    }

    @Override
    // viewname 어떻게 해석할거냐 부분 : 우리는 jsp 파일을 view로 쓸거예요
    // JSP 파일을 뷰 리졸버로 설정한다.
    // 이 메서드는 뷰 이름을 해석하여 JSP 파일로 매핑하는 설정을 정의한다.
    public void configureViewResolvers(ViewResolverRegistry registry){
        // InternalResourceViewResolver를 사용하여 JSP 파일을 뷰로 설정한다.
        InternalResourceViewResolver bean = new InternalResourceViewResolver();
        bean.setViewClass(JstlView.class); // JSP 파일에서 JSTL을 사용할 수 있도록 설정한다.
        bean.setPrefix("/WEB-INF/views/"); // JSP 파일이 위치할 디렉토리의 접두어를 설정한다.
        bean.setSuffix(".jsp"); // JSP 파일의 확장자를 설정한다.

        registry.viewResolver(bean); // 설정한 InternalResourceViewResolver를 등록한다.
    }

    @Bean
    // 파일 업로드를 처리하기 위한 MultipartResolver 빈을 생성한다.
    // 이 메서드는 Servlet 3.0의 파일 업로드 기능을 지원한다.
    public MultipartResolver multipartResolver() {
        // StandardServletMultipartResolver 객체를 생성하여 파일 업로드를 처리한다.
        StandardServletMultipartResolver resolver
                = new StandardServletMultipartResolver();
        return resolver;

        // 간단히 한 줄로 작성할 수 있다.
        // return new StandardServletMultipartResolver();
    }
}
