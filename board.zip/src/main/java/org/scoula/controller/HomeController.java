package org.scoula.controller;

import lombok.extern.slf4j.Slf4j; // SLF4J 로그 출력을 위한 Lombok 어노테이션
import org.springframework.stereotype.Controller; // Spring의 컨트롤러를 정의하는 어노테이션
import org.springframework.web.bind.annotation.GetMapping; // HTTP GET 요청을 처리하는 어노테이션

// 이 클래스는 Spring MVC의 컨트롤러 역할을 한다.
// @Controller 어노테이션을 통해 Spring이 이 클래스를 컨트롤러로 인식하게 한다.
@Controller

// log 라고 하는 멤버 변수 자동으로 생김 -> 이제부터 콘솔 출력 이걸로 할거임 이제 system.out 이거 안씀
// 로그 출력을 위해 SLF4J 로거를 자동으로 생성한다.
@Slf4j
public class HomeController {

    // HTTP GET 요청을 처리하는 메서드
    // "/" 경로로 들어오는 GET 요청을 이 메서드가 처리하도록 설정한다.
    @GetMapping("/")
    public String home() {
//        log.info("================> HomeController /"); // 로그 메시지를 출력한다. 이 메시지는 로그 설정에 따라 콘솔 또는 파일에 기록된다.
//        return "index"; // 뷰의 이름을 반환한다. 이 이름은 ViewResolver에 의해 JSP 파일로 매핑된다.

        return "redirect:/board/list";
    }

}
