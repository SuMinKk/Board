package org.scoula.board.service;

// BoardDTO 클래스를 임포트한다.
import org.scoula.board.domain.BoardAttachmentVO;
import org.scoula.board.dto.BoardDTO;

// List와 Optional 클래스를 임포트한다.
import java.util.List;
import java.util.Optional;

// BoardService 인터페이스를 정의한다. 이 인터페이스는 게시글 관련 비즈니스 로직을 처리하는 서비스 계층을 정의한다.
public interface BoardService {


    public List<BoardDTO> getList();

    public BoardDTO get(Long no);

    public void create(BoardDTO board);

    public boolean update(BoardDTO board);

    public boolean delete(Long no);

    public BoardAttachmentVO getAttachment(Long no);

    public boolean deleteAttachment(Long no);
}

