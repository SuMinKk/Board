// 패키지 선언: 이 클래스가 속한 패키지를 지정한다.
package org.scoula.board.dto;

// Lombok 라이브러리에서 필요한 어노테이션을 임포트한다.
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
// BoardVO 클래스를 임포트한다. DTO와 VO 간의 변환에 사용된다.
import org.scoula.board.domain.BoardAttachmentVO;
import org.scoula.board.domain.BoardVO;
import org.springframework.web.multipart.MultipartFile;
// Java의 날짜 및 시간 관련 클래스를 임포트한다.
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// @Data: 클래스에 대한 getter, setter, equals, hashCode, toString 메소드를 자동으로 생성한다.
// @NoArgsConstructor: 인자가 없는 기본 생성자를 자동으로 생성한다.
// @AllArgsConstructor: 모든 필드를 인자로 받는 생성자를 자동으로 생성한다.
// @Builder: 빌더 패턴을 사용하여 객체를 생성할 수 있도록 한다.
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardDTO {

    private Long no;         // 게시글 번호
    private String title;   // 게시글 제목
    private String content; // 게시글 내용
    private String writer;  // 게시글 작성자
    private Date regDate;   // 게시글 등록 날짜
    private Date updateDate; // 게시글 수정 날짜
    // 첨부 파일
    private List<BoardAttachmentVO> attaches;
    List<MultipartFile> files = new ArrayList<>(); // 실제 업로드된 파일(Multipart) 목록

    // VO  DTO 변환: BoardVO 객체를 BoardDTO 객체로 변환하는 정적 메소드
    public static BoardDTO of(BoardVO vo) {
        // vo가 null인 경우 null을 반환, 그렇지 않으면 BoardDTO 객체를 생성하여 반환한다.
        return vo == null ? null : BoardDTO.builder()


                .no(vo.getNo())            // VO의 no 필드를 DTO의 no 필드로 설정
                .title(vo.getTitle())      // VO의 title 필드를 DTO의 title 필드로 설정
                .content(vo.getContent())  // VO의 content 필드를 DTO의 content 필드로 설정
                .writer(vo.getWriter())    // VO의 writer 필드를 DTO의 writer 필드로 설정
                .attaches(vo.getAttaches())
                .regDate(vo.getRegDate())  // VO의 regDate 필드를 DTO의 regDate 필드로 설정
                .updateDate(vo.getUpdateDate()) // VO의 updateDate 필드를 DTO의 updateDate 필드로 설정
                .build(); // 빌더 패턴을 사용하여 BoardDTO 객체를 생성
    }

    // DTO  VO 변환: BoardDTO 객체를 BoardVO 객체로 변환하는 메소드
    public BoardVO toVo() {
        // BoardVO 객체를 빌더 패턴을 사용하여 생성하고, DTO의 필드 값을 설정한다.
        return BoardVO.builder()

                .no(no)                  // DTO의 no 필드를 VO의 no 필드로 설정
                .title(title)            // DTO의 title 필드를 VO의 title 필드로 설정
                .content(content)        // DTO의 content 필드를 VO의 content 필드로 설정
                .writer(writer)          // DTO의 writer 필드를 VO의 writer 필드로 설정
                .attaches(attaches)
                .regDate(regDate)        // DTO의 regDate 필드를 VO의 regDate 필드로 설정
                .updateDate(updateDate)  // DTO의 updateDate 필드를 VO의 updateDate 필드로 설정
                .build(); // 빌더 패턴을 사용하여 BoardVO 객체를 생성


    }
}
