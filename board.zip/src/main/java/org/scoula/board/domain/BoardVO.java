package org.scoula.board.domain;

import java.util.Date;  // 날짜와 시간을 표현하기 위해 사용하는 Java 클래스
import java.util.List;

import lombok.AllArgsConstructor;  // 모든 필드를 매개변수로 받는 생성자를 자동으로 생성
import lombok.Builder;           // 빌더 패턴을 적용하여 객체 생성을 지원
import lombok.Data;             // getter, setter, toString, equals, hashCode 메소드를 자동 생성
import lombok.NoArgsConstructor; // 기본 생성자를 자동으로 생성

/**
 * BoardVO 클래스는 게시글을 표현하기 위한 데이터 전송 객체(Data Transfer Object, DTO)이다.
 * MyBatis와 연동되어 `tbl_board` 테이블의 레코드를 Java 객체로 매핑하는 데 사용된다.
 */
@Data                  // Lombok의 @Data 어노테이션을 사용하여 getter, setter, toString, equals, hashCode 메소드를 자동으로 생성한다.
@NoArgsConstructor     // 기본 생성자를 자동으로 생성한다.
@AllArgsConstructor    // 모든 필드를 매개변수로 받는 생성자를 자동으로 생성한다.
@Builder               // 빌더 패턴을 사용하여 객체를 생성할 수 있도록 지원한다.
public class BoardVO {

    /**
     * 게시글의 고유 식별자(ID)
     * 데이터베이스의 자동 생성된 ID와 매핑된다.
     */
    private Long no;

    // 게시글 제목
    private String title;

    // 게시글 내용
    private String content;

    // 게시글 작성자의 이름
    private String writer;

    private List<BoardAttachmentVO> attaches;

    /**
     * 게시글이 등록된 날짜
     * Date 타입으로 날짜와 시간을 표현한다.
     */
    private Date regDate;

    /**
     * 게시글이 마지막으로 수정된 날짜
     * Date 타입으로 날짜와 시간을 표현한다.
     */
    private Date updateDate;
}
