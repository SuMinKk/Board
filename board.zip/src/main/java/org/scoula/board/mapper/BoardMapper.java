// 패키지 선언: 이 인터페이스가 속한 패키지를 지정한다.
package org.scoula.board.mapper;

// List와 BoardVO 클래스를 임포트한다.
import java.util.List;

import org.scoula.board.domain.BoardAttachmentVO;
import org.scoula.board.domain.BoardVO;

// BoardMapper 인터페이스를 정의한다.
// 이 인터페이스는 MyBatis의 매퍼 역할을 한다.
// MyBatis의 매퍼 역할은 데이터베이스와 Java 애플리케이션 간의 중개 역할을 하는 것이다
public interface BoardMapper {

    // @Select 어노테이션을 사용하여 SQL 쿼리를 정의한다.
    // @Select("select * from tbl_board order by no desc")

    // `getList` 메서드는 `tbl_board` 테이블의 모든 행을 조회하여 `BoardVO` 객체의 리스트로 반환한다.
    // 결과는 `no` 열을 기준으로 내림차순으로 정렬된다.
    // `List<BoardVO>`는 여러 개의 `BoardVO` 객체를 담을 수 있는 리스트이다.
    public List<BoardVO> getList();

    // `get` 메서드는 특정 `no` 값에 해당하는 게시글을 조회하여 `BoardVO` 객체로 반환한다.
    // 매개변수로 전달된 `no` 값에 따라 `tbl_board` 테이블에서 해당 행을 조회한다.
    public BoardVO get(Long no);

    // `create` 메서드는 새로운 게시글을 `tbl_board` 테이블에 삽입한다.
    // `BoardVO` 객체를 매개변수로 받아, 객체의 필드 값에 따라 새로운 레코드를 생성한다.
    public void create(BoardVO board);

    // `update` 메서드는 특정 게시글의 정보를 수정한다.
    // `BoardVO` 객체를 매개변수로 받아, 객체의 `no` 값에 해당하는 레코드를 찾아서 업데이트한다.
    // 업데이트할 필드 값은 `BoardVO` 객체의 필드 값으로 설정된다.
    public int update(BoardVO board);

    // `delete` 메서드는 특정 `no` 값을 가진 게시글을 `tbl_board` 테이블에서 삭제한다.
    // 매개변수로 전달된 `no` 값에 해당하는 레코드를 삭제하고, 삭제된 레코드 수를 반환한다.
    public int delete(Long no);


    public void createAttachment(BoardAttachmentVO attach);

    public List<BoardAttachmentVO> getAttachmentList(Long bno);

    public BoardAttachmentVO getAttachment(Long no);

    public int deleteAttachment(Long no);
}
