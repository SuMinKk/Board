package org.scoula.board.controller;

// Lombok 라이브러리의 RequiredArgsConstructor 어노테이션을 사용하여 final 필드에 대한 생성자를 자동으로 생성한다.
import lombok.RequiredArgsConstructor;

// BoardDTO 클래스는 데이터 전송 객체로, 게시판의 데이터를 담는다.
import org.scoula.board.domain.BoardAttachmentVO;
import org.scoula.board.dto.BoardDTO;

// BoardService는 비즈니스 로직을 처리하는 서비스 클래스이다.
import org.scoula.board.service.BoardService;

// Spring의 Controller 어노테이션으로, 이 클래스가 웹 요청을 처리하는 컨트롤러임을 명시한다.
import org.springframework.stereotype.Controller;

// Spring의 Model 클래스는 데이터를 뷰로 전달하는 데 사용된다.
import org.springframework.ui.Model;

// GET 요청을 처리하는 메서드에 사용되는 어노테이션이다.
import org.springframework.web.bind.annotation.*;

// POST 요청을 처리하는 메서드에 사용되는 어노테이션이다.

// 요청 경로를 매핑하는 데 사용되는 어노테이션이다.

// Lombok의 Log4j 어노테이션을 사용하여 로깅 기능을 제공한다.
import lombok.extern.log4j.Log4j;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import org.scoula.common.util.UploadFiles;

// 요청 파라미터를 메서드 매개변수로 주입할 때 사용된다.


@Controller  // 이 클래스가 Spring MVC의 컨트롤러임을 정의한다.
@Log4j  // Log4j를 사용하여 로그를 남길 수 있도록 한다.
@RequestMapping("/board")  // 모든 메서드는 기본적으로 "/board" 경로로 매핑된다.
@RequiredArgsConstructor  // final 필드를 사용하는 생성자를 자동으로 생성한다.
public class BoardController {

    final private BoardService service;  // BoardService를 주입받아 게시판 관련 비즈니스 로직을 처리한다.

    @GetMapping("/list")  // "/board/list" 경로로 들어오는 GET 요청을 처리한다.
    public void list(Model model) {
        log.info("list");  // 요청 처리 시작을 로그에 기록한다.
        model.addAttribute("list", service.getList());  // 모델에 "list"라는 이름으로 게시판 목록을 추가한다.
        // 반환 타입이 void 이므로, 뷰 이름을 반환하지 않고 Spring MVC가 뷰를 자동으로 찾아서 렌더링한다.
    }

    @GetMapping("/create")  // "/board/create" 경로로 들어오는 GET 요청을 처리한다.
    public void create() {
        log.info("create");  // 요청 처리 시작을 로그에 기록한다.
        // 반환 타입이 void 이므로, 뷰 이름을 반환하지 않고 Spring MVC가 뷰를 자동으로 찾아서 렌더링한다.
    }

    @PostMapping("/create")  // "/board/create" 경로로 들어오는 POST 요청을 처리한다.
    public String create(BoardDTO board) {
        log.info("create: " + board);  // 요청 처리 시작과 함께 게시판 DTO의 내용을 로그에 기록한다.
        service.create(board);  // 서비스 클래스를 호출하여 게시판을 생성한다.
        return "redirect:/board/list";  // 생성 후 게시판 목록 페이지로 리다이렉트한다.
    }

    @GetMapping({ "/get", "/update" })  // "/board/get" 또는 "/board/update" 경로로 들어오는 GET 요청을 처리한다.
    public void get(@RequestParam("no") Long no, Model model) {
        log.info("/get or update");  // 요청 처리 시작을 로그에 기록한다.
        model.addAttribute("board", service.get(no));  // 모델에 "board"라는 이름으로 게시판 상세 정보를 추가한다.
        // 반환 타입이 void 이므로, 뷰 이름을 반환하지 않고 Spring MVC가 뷰를 자동으로 찾아서 렌더링한다.
    }

    @PostMapping("/update")  // "/board/update" 경로로 들어오는 POST 요청을 처리한다.
    public String update(BoardDTO board) {
        log.info("update:" + board);  // 요청 처리 시작과 함께 게시판 DTO의 내용을 로그에 기록한다.
        service.update(board);  // 서비스 클래스를 호출하여 게시판 정보를 업데이트 한다.
        return "redirect:/board/list";  // 업데이트 후 게시판 목록 페이지로 리다이렉트한다.
    }

    @PostMapping("/delete")  // "/board/delete" 경로로 들어오는 POST 요청을 처리한다.
    public String delete(@RequestParam("no") Long no) {
        log.info("delete..." + no);  // 요청 처리 시작과 함께 삭제할 게시판 번호를 로그에 기록한다.
        service.delete(no);  // 서비스 클래스를 호출하여 게시판을 삭제한다.
        return "redirect:/board/list";  // 삭제 후 게시판 목록 페이지로 리다이렉트한다.
    }

    @GetMapping("/download/{no}")
    @ResponseBody // view를 사용하지 않고, 직접 내보냄
    public void download(@PathVariable("no") Long no, HttpServletResponse response) throws Exception {
        BoardAttachmentVO attach = service.getAttachment(no);
        File file = new File(attach.getPath());
        UploadFiles.download(response, file, attach.getFilename());
    }
}
