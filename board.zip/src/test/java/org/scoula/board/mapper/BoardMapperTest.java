// 패키지 선언: 이 테스트 클래스가 속한 패키지를 지정한다.
package org.scoula.board.mapper;

// 로깅을 위한 Log4j를 임포트한다.
import lombok.extern.log4j.Log4j;
// JUnit 5의 테스트 관련 어노테이션을 임포트한다.
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
// BoardVO 클래스를 임포트한다.
import org.scoula.board.domain.BoardVO;
// Spring의 설정 클래스를 임포트한다.
import org.scoula.config.RootConfig;
// Spring의 테스트 관련 클래스를 임포트한다.
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

// JUnit 5의 SpringExtension을 사용하여 Spring 컨텍스트와 통합된 테스트를 지원한다.
// RootConfig 클래스를 통해 Spring 설정을 로드한다.
// Log4j를 사용하여 로깅 기능을 제공한다.
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {RootConfig.class})
@Log4j
public class BoardMapperTest {

    // BoardMapper를 자동으로 주입받는다.
    @Autowired
    private BoardMapper mapper;

    // `getList` 메서드 테스트
    @Test
    @DisplayName("BoardMapper의 목록 불러오기")
    public void getList() {
        // `mapper.getList()` 메서드를 호출하여 모든 게시글을 가져오고, 각 게시글을 로그로 출력한다.
        for (BoardVO board : mapper.getList()) {
            log.info(board);
        }
    }

    // `get` 메서드 테스트
    @Test
    @DisplayName("BoardMapper의 게시글 읽기")
    public void get() {
        // 존재하는 게시물 번호(1L)를 사용하여 게시글을 조회하고, 로그로 출력한다.
        BoardVO board = mapper.get(1L);
        log.info(board);
    }

    // `create` 메서드 테스트
    @Test
    @DisplayName("BoardMapper의 새글 작성")
    public void create() {
        // 새 게시글을 작성하기 위해 BoardVO 객체를 생성하고, 필드 값을 설정한다.
        BoardVO board = new BoardVO();
        board.setTitle("새로 작성하는 글");
        board.setContent("새로 작성하는 내용");
        board.setWriter("user0");

        // `mapper.create()` 메서드를 호출하여 게시글을 데이터베이스에 삽입한다.
        mapper.create(board);

        // 작성된 게시글 정보를 로그로 출력한다.
        log.info(board);
    }

    // `update` 메서드 테스트
    @Test
    @DisplayName("BoardMapper의 글 수정")
    public void update() {
        // 수정할 게시글을 위해 BoardVO 객체를 생성하고, 필드 값을 설정한다.
        BoardVO board = new BoardVO();
        board.setNo(5L);  // 수정할 게시글의 번호
        board.setTitle("수정된 제목");
        board.setContent("수정된 내용");
        board.setWriter("user00");

        // `mapper.update()` 메서드를 호출하여 게시글을 수정하고, 수정된 레코드의 수를 로그로 출력한다.
        int count = mapper.update(board);
        log.info("UPDATE COUNT: " + count);
    }

    // `delete` 메서드 테스트
    @Test
    @DisplayName("BoardMapper의 글 삭제")
    public void delete() {
        // 게시글 번호(3L)를 사용하여 게시글을 삭제하고, 삭제된 레코드의 수를 로그로 출력한다.
        log.info("DELETE COUNT: " + mapper.delete(3L));
    }
}
