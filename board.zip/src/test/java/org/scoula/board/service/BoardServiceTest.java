package org.scoula.board.service;

// 로깅을 위한 Log4j를 임포트한다.

import lombok.extern.log4j.Log4j;
// JUnit 5의 어서션과 테스트 관련 클래스를 임포트한다.
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
// BoardDTO 클래스를 임포트한다.
import org.scoula.board.dto.BoardDTO;
// Spring의 설정 클래스를 임포트한다.
import org.scoula.config.RootConfig;
// Spring의 테스트 관련 클래스를 임포트한다.
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
// 트랜잭션 관리를 위한 어노테이션을 임포트한다.
import org.springframework.transaction.annotation.Transactional;

// JUnit 5의 SpringExtension을 사용하여 Spring 컨텍스트와 통합된 테스트를 지원한다.
// RootConfig 클래스를 통해 Spring 설정을 로드한다.
// Log4j를 사용하여 로깅 기능을 제공한다.
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {RootConfig.class})
@Log4j
@Transactional // 테스트가 완료되면 트랜잭션을 롤백하여 데이터베이스의 상태를 원래대로 돌린다.
class BoardServiceTest {

    // BoardService를 자동으로 주입받는다.
    @Autowired
    private BoardService service;

    // `getList` 메서드 테스트
    @Test
    void getList() {
        // 서비스의 게시글 목록을 가져와서 로그로 출력한다.
        for (BoardDTO board : service.getList()) {
            log.info(board);
        }
    }

    // `get` 메서드 테스트
    @Test
    void get() {
        // 특정 게시글을 조회하고, 로그로 출력한다.
        log.info(service.get(1L));

//        //given
//        long id = 1L;
//        // when
//        BoardDTO post = service.get(id);
//        //then
//        Assertions.assertEquals(post.getTitle(), "수정된 테스트 새글 제목");
    }

    // `create` 메서드 테스트
    @Transactional // 메서드 내에서 트랜잭션을 관리한다.
    @Test
    void create() {
        // 새 게시글을 작성하기 위해 BoardDTO 객체를 생성하고, 필드 값을 설정한다.
        BoardDTO board = new BoardDTO();
        board.setTitle("새로 작성하는 글");
        board.setContent("새로 작성하는 내용");
        board.setWriter("user1");

        // 게시글을 생성하고, 생성된 게시물의 번호를 로그로 출력한다.
        service.create(board);
        log.info("생성된 게시물의 번호: " + board.getNo());
    }

    // `update` 메서드 테스트
    @Test
    void update() {
        // 게시글을 조회하여 수정한 후, 수정 결과를 로그로 출력한다.
        BoardDTO board = service.get(1L);
        board.setTitle("제목 수정합니다.");
        log.info("update RESULT: " + service.update(board));
    }

    // `delete` 메서드 테스트
    @Test
    void delete() {
        // 게시물 번호(2L)를 사용하여 게시글을 삭제하고, 삭제 결과를 로그로 출력한다.
        log.info("delete RESULT: " + service.delete(2L));
    }
}
