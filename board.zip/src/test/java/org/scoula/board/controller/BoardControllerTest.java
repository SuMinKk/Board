// 패키지 선언: 이 클래스가 속한 패키지를 지정한다.
package org.scoula.board.controller;

// Lombok의 Log4j를 사용하여 로깅 기능을 제공하는 클래스를 임포트한다.
import lombok.extern.log4j.Log4j;

// JUnit 5의 BeforeEach 애너테이션을 사용하여 각 테스트 메소드 실행 전에 수행할 작업을 정의한다.
import org.junit.jupiter.api.BeforeEach;

// JUnit 5의 Test 애너테이션을 사용하여 테스트 메소드를 정의한다.
import org.junit.jupiter.api.Test;

// JUnit 5의 테스트 확장 기능을 제공하는 클래스를 임포트한다.
import org.junit.jupiter.api.extension.ExtendWith;

// BoardService 인터페이스를 임포트하여 테스트에서 사용할 서비스 객체를 주입받는다.
import org.scoula.board.service.BoardService;

// Spring의 RootConfig 클래스를 임포트하여 Spring의 설정을 가져온다.
import org.scoula.config.RootConfig;

// Spring의 ServletConfig 클래스를 임포트하여 서블릿 관련 설정을 가져온다.
import org.scoula.config.ServletConfig;

// Spring의 애플리케이션 컨텍스트를 주입받아 웹 애플리케이션 컨텍스트를 설정한다.
import org.springframework.beans.factory.annotation.Autowired;

// Spring의 ContextConfiguration 애너테이션을 사용하여 테스트에 사용할 설정 클래스를 지정한다.
import org.springframework.test.context.ContextConfiguration;

// JUnit 5와 Spring의 통합을 위한 애너테이션이다.
import org.springframework.test.context.junit.jupiter.SpringExtension;

// 웹 애플리케이션 컨텍스트를 설정하기 위해 사용되는 애너테이션이다.
import org.springframework.test.context.web.WebAppConfiguration;

// Spring MVC 테스트를 위한 MockMvc 클래스를 임포트한다.
import org.springframework.test.web.servlet.MockMvc;

// MockMvcRequestBuilders를 사용하여 HTTP 요청을 생성한다.
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

// MockMvc를 설정하고 테스트를 위한 MockMvc 객체를 생성한다.
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

// 웹 애플리케이션 컨텍스트를 가져와서 MockMvc를 설정하는 데 사용한다.
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;


@Transactional
@Log4j // Log4j를 사용하여 로깅 기능을 제공하는 Lombok 애너테이션
@WebAppConfiguration // 웹 애플리케이션 컨텍스트를 설정하기 위한 애너테이션
@ContextConfiguration(classes = { RootConfig.class, ServletConfig.class }) // 테스트에 사용할 Spring 설정 클래스를 지정한다.
@ExtendWith(SpringExtension.class) // JUnit 5와 Spring의 통합을 위한 애너테이션
public class BoardControllerTest {

    // BoardService 인터페이스를 주입받아 테스트에서 사용할 수 있게 한다.
    @Autowired
    BoardService service;

    // WebApplicationContext를 주입받아 MockMvc를 설정하는 데 사용한다.
    @Autowired
    private WebApplicationContext ctx;

    // MockMvc 객체를 선언한다. MockMvc는 Spring MVC 테스트를 위한 객체이다.
    private MockMvc mockMvc;

    // 각 테스트 메소드 실행 전에 수행할 작업을 정의하는 메소드이다.
    @BeforeEach
    public void setup() {
        // WebApplicationContext를 사용하여 MockMvc 객체를 설정한다.
        this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
    }

    // 게시글 목록을 요청하고 결과를 로깅하는 테스트 메소드
    @Test
    public void list() throws Exception {
        // MockMvc를 사용하여 GET 요청을 '/board/list' 엔드포인트로 보내고 결과를 로깅한다.
        log.info(
                mockMvc.perform(MockMvcRequestBuilders.get("/board/list")) // GET 요청을 보내는 메소드
                        .andReturn() // 요청의 결과를 반환받는다.
                        .getModelAndView() // ModelAndView를 반환받아 뷰와 모델을 가져온다.
                        .getModelMap() // 모델을 가져온다.
        );
    }

    // 새 게시글을 생성하는 요청을 테스트하는 메소드
    @Test
    public void create() throws Exception {
        // MockMvc를 사용하여 POST 요청을 '/board/create' 엔드포인트로 보내고, 요청 파라미터를 설정한다.
        String resultPage = mockMvc
                .perform(
                        MockMvcRequestBuilders.post("/board/create")
                                .param("title", "테스트 새글 제목") // 요청 파라미터로 제목을 설정한다.
                                .param("content", "테스트 새글 내용") // 요청 파라미터로 내용 설정
                                .param("writer", "user1") // 요청 파라미터로 작성자 설정
                )
                .andReturn() // 요청의 결과를 반환받는다.
                .getModelAndView() // ModelAndView를 반환받아 뷰와 모델을 가져온다.
                .getViewName(); // 뷰의 이름을 가져온다.
        log.info(resultPage); // 결과 페이지 이름을 로깅한다.
    }

    // 게시글을 조회하는 요청을 테스트하는 메소드
    @Test
    public void get() throws Exception {
        // MockMvc를 사용하여 GET 요청을 '/board/get' 엔드포인트로 보내고, 게시글 번호를 파라미터로 설정한다.
        log.info(
                mockMvc.perform(MockMvcRequestBuilders.get("/board/get").param("no", "1")) // 게시글 번호를 파라미터로 설정한다.
                        .andReturn() // 요청의 결과를 반환받는다.
                        .getModelAndView() // ModelAndView를 반환받아 뷰와 모델을 가져온다.
                        .getModelMap() // 모델을 가져온다.
        );
    }

    // 게시글을 수정하는 요청을 테스트하는 메소드
    @Test
    public void update() throws Exception {
        // MockMvc를 사용하여 POST 요청을 '/board/update' 엔드포인트로 보내고, 요청 파라미터를 설정한다.
        String resultPage = mockMvc.perform(
                        MockMvcRequestBuilders.post("/board/update")
                                .param("no", "1") // 게시글 번호를 파라미터로 설정한다.
                                .param("title", "수정된 테스트 새글 제목") // 요청 파라미터로 제목을 수정한다.
                                .param("content", "수정된 테스트 새글 내용") // 요청 파라미터로 내용 수정
                                .param("writer", "user00") // 요청 파라미터로 작성자 수정
                )
                .andReturn() // 요청의 결과를 반환받는다.
                .getModelAndView() // ModelAndView를 반환받아 뷰와 모델을 가져온다.
                .getViewName(); // 뷰의 이름을 가져온다.
        log.info(resultPage); // 결과 페이지 이름을 로깅한다.
    }

    // 게시글을 삭제하는 요청을 테스트하는 메소드
    @Test
    public void delete() throws Exception {
        // 삭제 전 데이터베이스에 게시물 번호를 확인해야 한다.
        // MockMvc를 사용하여 POST 요청을 '/board/delete' 엔드포인트로 보내고, 요청 파라미터를 설정한다.
        String resultPage = mockMvc.perform(
                        MockMvcRequestBuilders
                                .post("/board/delete")
                                .param("no", "25") // 삭제할 게시글 번호를 파라미터로 설정한다.
                )
                .andReturn() // 요청의 결과를 반환받는다.
                .getModelAndView() // ModelAndView를 반환받아 뷰와 모델을 가져온다.
                .getViewName(); // 뷰의 이름을 가져온다.
        log.info(resultPage); // 결과 페이지 이름을 로깅한다.
    }
}
