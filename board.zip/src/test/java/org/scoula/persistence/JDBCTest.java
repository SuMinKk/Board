package org.scoula.persistence;

// 로깅을 위한 Log4j를 임포트한다.
import lombok.extern.log4j.Log4j;
// JUnit 5의 테스트 관련 어노테이션을 임포트한다.
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;

import static org.junit.jupiter.api.Assertions.fail;

// Log4j를 사용하여 로깅 기능을 제공한다.
@Log4j
public class JDBCTest {

    // 정적 블록에서 MySQL JDBC 드라이버를 로드한다.
    static {
        try {
            // MySQL JDBC 드라이버 클래스를 로드한다.
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            // 드라이버 로드에 실패하면 스택 트레이스를 출력한다.
            e.printStackTrace();
        }
    }

    // JDBC 연결 테스트
    @Test
    @DisplayName("JDBC 드라이버 연결이 된다.")
    public void testConnection() {
        // 데이터베이스 URL 설정
        String url = "jdbc:mysql://localhost:3306/scoula_db";
        try (Connection con = DriverManager.getConnection(url, "scoula", "1234")) {
            // 데이터베이스 연결이 성공하면 연결 객체를 로그로 출력한다.
            log.info(con);
        } catch (Exception e) {
            // 연결에 실패하면 테스트를 실패로 간주하고 예외 메시지를 출력한다.
            fail(e.getMessage());
        }
    }
}
