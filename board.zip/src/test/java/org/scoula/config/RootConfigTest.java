package org.scoula.config;

// 로깅을 위한 Log4j를 임포트한다.
import lombok.extern.log4j.Log4j;
// MyBatis의 SqlSession 및 SqlSessionFactory 클래스를 임포트한다.
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
// JUnit 5의 테스트 관련 어노테이션을 임포트한다.
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
// Spring의 설정 클래스를 임포트한다.
import org.scoula.config.RootConfig;
// Spring의 테스트 관련 클래스를 임포트한다.
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

import static org.springframework.test.util.AssertionErrors.fail;

// JUnit 5의 SpringExtension을 사용하여 Spring 컨텍스트와 통합된 테스트를 지원한다.
// RootConfig 클래스를 통해 Spring 설정을 로드한다.
// Log4j를 사용하여 로깅 기능을 제공한다.
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {RootConfig.class})
@Log4j
class RootConfigTest {

    // DataSource를 자동으로 주입받아 테스트에 사용한다.
    @Autowired
    private DataSource dataSource;

    // SqlSessionFactory를 자동으로 주입받아 테스트에 사용한다.
    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    // DataSource의 연결 테스트
    @Test
    @DisplayName("DataSource 연결이 된다.")
    public void dataSource() throws SQLException {
        // DataSource에서 커넥션을 가져와서 로그로 출력한다.
        try (Connection con = dataSource.getConnection()) {
            log.info("DataSource 준비 완료");
            log.info(con);
        }
    }

    // SqlSessionFactory의 세션 테스트
    @Test
    public void testSqlSessionFactory() {
        // SqlSession을 열고, 해당 세션의 커넥션을 가져와서 로그로 출력한다.
        try (
                SqlSession session = sqlSessionFactory.openSession();
                Connection con = session.getConnection();
        ) {
            log.info(session);
            log.info(con);
        } catch (Exception e) {
            // 예외가 발생하면 테스트를 실패로 간주하고 예외 메시지를 로그로 출력한다.
            fail(e.getMessage());
        }
    }
}
